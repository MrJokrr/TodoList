from flask import Flask, render_template, request as r
#from flask_restful import Api, Resource, reqparse
from time import ctime
import json

app = Flask(__name__)
#api = Api(app)

"""API можна використати за допомогою юрлів ../get, ../add ../change i ../delete та пост запитів """
#Todo = {}


Todo = [{"id": '1', "Time_Create": ctime(), "Task": "Some task", "Done": 0}]

'''
class Task(Resource):
    def get(self, id=0):
        if id == 0:  # show whole TodoList
            return Todo, 200
        elif id in Todo:
            return Todo[id], 200
        return "Quote not found", 404

    def add(self, id):
        parser = reqparse.RequestParser()
        parser.add_argument("done")
        parser.add_argument("task")
        params = parser.parse_args()
        if id in Todo:
            return f"Quote with id {id} already exists", 400
        task = {
            "id": int(id),
            "Time_Create": ctime(),
            "Done": params["done"],
            "Task": params["task"]
        }
        Todo[id] = task
        return task, 201

    def put(self, id, done):
        parser = reqparse.RequestParser()
    #    parser.add_argument("task")
        parser.add_argument("done")
        params = parser.parse_args()

        time_m = ctime()

        if id in Todo:
            Todo[id]["Time_mod"] = time_m()
    #       i["Task"] = params["task"]
            Todo[id]["Done"] = params["done"]
            return Todo[id], 200

        task = {
            "id": id,
            "Time_create": time_m,
            "Done": params["done"],
            "Task": params["task"]
        }

        Todo[id] = task
        return task, 201

    def delete(self, id):
        global Todo
    #    Todo = [i for i in Todo if i["id"] != id]
        if id == 0:
            Todo.clear()
            return "The TodoList has been deleted", 200

        if id in Todo:
            Todo.pop(id)
            return f"Quote with id {id} is deleted.", 200


api.add_resource(Task, "/Todo", "/Todo/", "/Todo/<int:id>")
if __name__ == '__main__':
    app.run(debug=True)
'''

def si(e):
    global Todo
    for i in range(len(Todo)):
        if e == Todo[i]['id']:
            return i
    return None

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/get', methods = ['POST', 'GET'])
def get():
    ind = si(r.form['id'])
    if r.form['id'] == '0':
        #return render_template('index.html', a = json.dumps(Todo))
        return json.dumps(Todo)
    if ind != None:
        #return render_template('index.html', a = json.dumps([Todo[ind]]))
        return json.dumps([Todo[ind]])
    return render_template('index.html', a="Id not in TodoList")

@app.route('/add', methods=['POST', 'GET'])
def add():
    ind = si(r.form['id'])
    if ind == None:
        Todo.append({"id": r.form['id'], "Time_Create": ctime(), "Task": r.form['taska'], "Done": 0})
        #return render_template('index.html', a = Todo[-1])
        return json.dumps([Todo[-1]])
    return render_template('index.html', a="Id already in TodoList")


@app.route('/change', methods=['POST', 'GET'])
def change():
    ind = si(r.form['id'])

    if ind != None:
        if 'done' in r.form and r.form['done'] == 'on':
            Todo[ind]['Done'] = 1
            Todo[ind]['Time_Mod'] = ctime()
        elif 'done' not in r.form or r.form['done'] != 'on':
            Todo[ind]['Done'] = 0
            Todo[ind]['Time_Mod'] = ctime()
        #return render_template('index.html', a = Todo[ind])
        return json.dumps([Todo[ind]])
    return render_template('index.html', a="Id not in TodoList")

@app.route('/delete', methods=['POST', 'GET'])
def delete():
    ind = si(r.form['id'])
    if r.form['id'] == '0':
        Todo.clear()
        return render_template('index.html')
    elif ind != None:
        #return render_template('index.html', a = Todo.pop(ind-1))
        json.dumps([Todo.pop(ind)])
    return render_template('index.html', a = "Id not in TodoList")